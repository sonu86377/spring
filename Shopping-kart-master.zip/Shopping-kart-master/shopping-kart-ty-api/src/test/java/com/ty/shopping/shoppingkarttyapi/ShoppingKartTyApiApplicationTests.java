package com.ty.shopping.shoppingkarttyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingKartTyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
