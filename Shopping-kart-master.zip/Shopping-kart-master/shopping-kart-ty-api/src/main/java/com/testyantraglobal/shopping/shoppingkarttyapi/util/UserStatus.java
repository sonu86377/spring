package com.testyantraglobal.shopping.shoppingkarttyapi.util;

public enum UserStatus {

	ACTIVE, IN_ACTIVE, BLOCKED;

}
