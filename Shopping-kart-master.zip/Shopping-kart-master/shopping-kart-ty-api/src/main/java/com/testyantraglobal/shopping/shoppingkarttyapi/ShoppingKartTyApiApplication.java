package com.testyantraglobal.shopping.shoppingkarttyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingKartTyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingKartTyApiApplication.class, args);
	}

}
