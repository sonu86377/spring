package com.ty.hospitalbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalBootAppApplication.class, args);
	}

}
