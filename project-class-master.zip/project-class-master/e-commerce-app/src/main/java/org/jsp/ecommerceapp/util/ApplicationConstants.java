package org.jsp.ecommerceapp.util;

public interface ApplicationConstants {
	String VERIFY_LINK = "/merchants/activate?token=";
	String USER_VERIFY_LINK = "/users/activate?token=";
}
