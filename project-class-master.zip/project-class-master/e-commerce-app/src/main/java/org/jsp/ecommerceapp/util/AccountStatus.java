package org.jsp.ecommerceapp.util;

public enum AccountStatus {
	ACTIVE, IN_ACTIVE, BLOCKED;
}
