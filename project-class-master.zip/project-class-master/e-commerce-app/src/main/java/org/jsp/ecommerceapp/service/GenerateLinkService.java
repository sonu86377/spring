package org.jsp.ecommerceapp.service;

public class GenerateLinkService {

}
