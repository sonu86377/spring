import React from 'react'

 function Error() {
  return (
    <div>Error
        <h1>404 Page Not Found</h1>
        <img src="https://colorlib.com/wp/wp-content/uploads/sites/2/404-error-page-templates.jpg" alt="" />
    </div>
  )
}
export default Error
